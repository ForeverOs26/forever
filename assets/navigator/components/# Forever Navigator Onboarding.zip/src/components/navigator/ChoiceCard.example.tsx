import { useState } from "react";
import ChoiceCard from "./ChoiceCard";

/**
 * Example usage for ChoiceCard.
 *
 * ChoiceCard is pure UI — ALL selection logic lives here in the parent.
 * This demo shows the frozen Navigator rules: multi-select, max 3 with a
 * FIFO roll-off, and unselected cards disabled ("dimmed") once the max is
 * reached. Integration into real screens happens separately.
 */
const OPTIONS = [
  { key: "second_home", label: "A second home by the sea" },
  { key: "retirement", label: "Retirement in a warmer climate" },
  { key: "investment", label: "Investment & rental income" },
  { key: "slower_life", label: "A slower way of living" },
  { key: "family", label: "A place for my family" },
  { key: "wellbeing", label: "Better weather and wellbeing" },
];

const MAX = 3;

export default function ChoiceCardExample() {
  const [selected, setSelected] = useState<string[]>([]);

  function toggle(key: string) {
    setSelected((prev) => {
      if (prev.includes(key)) return prev.filter((k) => k !== key);
      if (prev.length >= MAX) return [...prev.slice(1), key]; // FIFO roll-off
      return [...prev, key];
    });
  }

  const atMax = selected.length >= MAX;

  return (
    <div
      role="group"
      aria-label="Why Phuket — select up to three"
      className="mx-auto flex w-full max-w-md flex-col gap-[10px] p-6"
    >
      {OPTIONS.map((o) => {
        const isSelected = selected.includes(o.key);
        return (
          <ChoiceCard
            key={o.key}
            title={o.label}
            selected={isSelected}
            disabled={atMax && !isSelected}
            onClick={() => toggle(o.key)}
          />
        );
      })}
    </div>
  );
}
