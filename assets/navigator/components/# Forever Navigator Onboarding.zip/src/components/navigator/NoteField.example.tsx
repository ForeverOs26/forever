import { useState } from "react";
import NoteField from "./NoteField";

/**
 * Example usage for NoteField.
 *
 * Presentation only — the value lives HERE in the parent. This demo mirrors
 * the optional note on the Biggest Concern screen: a 500-char cap with a live
 * counter. All truncation/state handling stays in the parent.
 */
export default function NoteFieldExample() {
  const [note, setNote] = useState("");

  return (
    <div className="mx-auto w-full max-w-md p-6">
      <NoteField
        value={note}
        onChange={setNote}
        label="Anything else on your mind?"
        placeholder="Anything else on your mind? (optional)"
        maxLength={500}
        showCounter
      />
    </div>
  );
}
