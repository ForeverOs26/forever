import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, it, expect, vi } from "vitest";
import NoteField from "./NoteField";

describe("NoteField", () => {
  it("renders an accessible textarea with placeholder", () => {
    render(
      <NoteField
        value=""
        onChange={() => {}}
        label="Anything else on your mind?"
        placeholder="Anything else on your mind? (optional)"
      />,
    );
    const ta = screen.getByLabelText("Anything else on your mind?");
    expect(ta).toBeInTheDocument();
    expect(ta).toHaveAttribute("placeholder", "Anything else on your mind? (optional)");
  });

  it("calls onChange with the new value as the user types", async () => {
    const onChange = vi.fn();
    render(<NoteField value="" onChange={onChange} label="Note" />);
    await userEvent.type(screen.getByLabelText("Note"), "Hi");
    expect(onChange).toHaveBeenCalled();
    expect(onChange).toHaveBeenLastCalledWith("Hi");
  });

  it("shows a counter tied to maxLength when enabled", () => {
    render(
      <NoteField value="hello" onChange={() => {}} label="Note" maxLength={500} showCounter />,
    );
    expect(screen.getByText("5 / 500")).toBeInTheDocument();
  });

  it("applies maxLength to the textarea", () => {
    render(<NoteField value="" onChange={() => {}} label="Note" maxLength={120} />);
    expect(screen.getByLabelText("Note")).toHaveAttribute("maxlength", "120");
  });

  it("is disabled and non-editable when disabled", async () => {
    const onChange = vi.fn();
    render(<NoteField value="" onChange={onChange} label="Note" disabled />);
    const ta = screen.getByLabelText("Note");
    expect(ta).toBeDisabled();
    await userEvent.type(ta, "x");
    expect(onChange).not.toHaveBeenCalled();
  });

  it("links the counter to the field via aria-describedby", () => {
    render(
      <NoteField value="" onChange={() => {}} label="Note" maxLength={500} showCounter />,
    );
    const ta = screen.getByLabelText("Note");
    const describedby = ta.getAttribute("aria-describedby");
    expect(describedby).toBeTruthy();
    expect(document.getElementById(describedby as string)).toHaveTextContent("0 / 500");
  });
});
