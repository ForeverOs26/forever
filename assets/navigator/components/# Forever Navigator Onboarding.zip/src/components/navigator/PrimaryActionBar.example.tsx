import { useState } from "react";
import PrimaryActionBar from "./PrimaryActionBar";

/**
 * Example usage for PrimaryActionBar.
 *
 * Presentation only — disabled/loading state lives HERE in the parent. This
 * demo toggles a selection to enable the primary action, and simulates a
 * brief loading state on tap (as the "See my Forever Story" step would while
 * the story generates). It also shows the optional secondary text action.
 */
export default function PrimaryActionBarExample() {
  const [chosen, setChosen] = useState(false);
  const [loading, setLoading] = useState(false);

  function submit() {
    setLoading(true);
    setTimeout(() => setLoading(false), 1500); // stand-in for async work
  }

  return (
    <div className="mx-auto flex min-h-dvh w-full max-w-md flex-col bg-white">
      <div className="flex-1 p-[26px]">
        <button
          type="button"
          onClick={() => setChosen((v) => !v)}
          className={[
            "w-full rounded-[15px] border px-[18px] py-[17px] text-left text-[15.5px]",
            "[font-family:'Hanken_Grotesk',system-ui,sans-serif]",
            chosen
              ? "border-[1.5px] border-[#17150F] bg-[#F3EFE7] font-[600] text-[#17150F]"
              : "border-[#EAE6DE] bg-white font-[500] text-[#3A362E]",
          ].join(" ")}
        >
          A peaceful place to live
        </button>
      </div>

      <PrimaryActionBar
        primaryLabel="See my Forever Story"
        onPrimary={submit}
        disabled={!chosen}
        loading={loading}
        secondaryLabel="Maybe later"
        onSecondary={() => setChosen(false)}
      />
    </div>
  );
}
