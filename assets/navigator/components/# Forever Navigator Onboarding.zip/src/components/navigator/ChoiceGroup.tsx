import ChoiceCard from "./ChoiceCard";
import type { ReactNode } from "react";

/**
 * ChoiceGroup — Forever Navigator
 *
 * Presentational, controlled layout wrapper around a set of ChoiceCards.
 * It owns NO state and NO selection rules (max-N, FIFO, exclusivity all live
 * in the parent). It only:
 *   - lays the cards out on the frozen rhythm (single column on mobile,
 *     two columns >=768px), and
 *   - provides group semantics (role="group" + accessible name).
 *
 * Selection is fully controlled: the parent passes `selectedKeys`, optionally
 * `disabledKeys`, and an `onToggle(key)` callback.
 */
export interface ChoiceGroupItem {
  key: string;
  title: string;
  description?: string;
  icon?: ReactNode;
  /** Render a hairline divider immediately before this item (e.g. an
   *  "exclusive"/opt-out option set apart from the rest). Presentation only. */
  dividerBefore?: boolean;
  /** Visual italic + dashed treatment for opt-out style items. */
  muted?: boolean;
}

export interface ChoiceGroupProps {
  /** Accessible name for the group, e.g. "Why Phuket — select up to three". */
  ariaLabel: string;
  items: ChoiceGroupItem[];
  /** Controlled selection (owned by the parent). */
  selectedKeys: string[];
  /** Optional controlled disabled set (e.g. dimmed once a max is reached). */
  disabledKeys?: string[];
  /** Fired with the item key on click / keyboard activation. */
  onToggle: (key: string) => void;
  className?: string;
}

export default function ChoiceGroup({
  ariaLabel,
  items,
  selectedKeys,
  disabledKeys = [],
  onToggle,
  className = "",
}: ChoiceGroupProps) {
  return (
    <div
      role="group"
      aria-label={ariaLabel}
      className={[
        "grid grid-cols-1 gap-[10px] md:grid-cols-2 md:gap-[11px]",
        className,
      ].join(" ")}
    >
      {items.map((item) => {
        const card = (
          <ChoiceCard
            title={item.title}
            description={item.description}
            icon={item.icon}
            selected={selectedKeys.includes(item.key)}
            disabled={disabledKeys.includes(item.key)}
            onClick={() => onToggle(item.key)}
            className={item.muted ? "border-dashed italic" : undefined}
          />
        );

        if (item.dividerBefore) {
          return (
            // `contents` keeps the divider + card flowing in the grid without
            // introducing an extra layout box.
            <div key={item.key} className="contents">
              <div
                aria-hidden="true"
                className="col-span-full mx-[2px] my-[4px] h-px bg-[#F1EDE6]"
              />
              {card}
            </div>
          );
        }
        return <div key={item.key} className="contents">{card}</div>;
      })}
    </div>
  );
}
