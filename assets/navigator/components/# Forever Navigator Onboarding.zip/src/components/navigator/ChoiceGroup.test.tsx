import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, it, expect, vi } from "vitest";
import ChoiceGroup from "./ChoiceGroup";
import type { ChoiceGroupItem } from "./ChoiceGroup";

const ITEMS: ChoiceGroupItem[] = [
  { key: "second_home", title: "A second home by the sea" },
  { key: "investment", title: "Investment & rental income" },
  { key: "slower_life", title: "A slower way of living" },
  { key: "exploring", title: "I'm still exploring", dividerBefore: true, muted: true },
];

describe("ChoiceGroup", () => {
  it("renders one card per item with a named group", () => {
    render(
      <ChoiceGroup
        ariaLabel="Why Phuket — select up to three"
        items={ITEMS}
        selectedKeys={[]}
        onToggle={() => {}}
      />,
    );
    expect(
      screen.getByRole("group", { name: "Why Phuket — select up to three" }),
    ).toBeInTheDocument();
    expect(screen.getAllByRole("checkbox")).toHaveLength(ITEMS.length);
  });

  it("reflects controlled selection via aria-checked", () => {
    render(
      <ChoiceGroup
        ariaLabel="Group"
        items={ITEMS}
        selectedKeys={["investment"]}
        onToggle={() => {}}
      />,
    );
    expect(
      screen.getByRole("checkbox", { name: "Investment & rental income" }),
    ).toHaveAttribute("aria-checked", "true");
    expect(
      screen.getByRole("checkbox", { name: "A second home by the sea" }),
    ).toHaveAttribute("aria-checked", "false");
  });

  it("calls onToggle with the item key when a card is activated", async () => {
    const onToggle = vi.fn();
    render(
      <ChoiceGroup
        ariaLabel="Group"
        items={ITEMS}
        selectedKeys={[]}
        onToggle={onToggle}
      />,
    );
    await userEvent.click(
      screen.getByRole("checkbox", { name: "A slower way of living" }),
    );
    expect(onToggle).toHaveBeenCalledWith("slower_life");
  });

  it("disables the cards named in disabledKeys and suppresses their toggle", async () => {
    const onToggle = vi.fn();
    render(
      <ChoiceGroup
        ariaLabel="Group"
        items={ITEMS}
        selectedKeys={[]}
        disabledKeys={["second_home"]}
        onToggle={onToggle}
      />,
    );
    const disabled = screen.getByRole("checkbox", { name: "A second home by the sea" });
    expect(disabled).toBeDisabled();
    await userEvent.click(disabled);
    expect(onToggle).not.toHaveBeenCalled();
  });
});
