import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, it, expect, vi } from "vitest";
import PrimaryActionBar from "./PrimaryActionBar";

describe("PrimaryActionBar", () => {
  it("renders the primary label and fires onPrimary", async () => {
    const onPrimary = vi.fn();
    render(<PrimaryActionBar primaryLabel="Continue" onPrimary={onPrimary} />);
    await userEvent.click(screen.getByRole("button", { name: "Continue" }));
    expect(onPrimary).toHaveBeenCalledTimes(1);
  });

  it("does not fire onPrimary when disabled", async () => {
    const onPrimary = vi.fn();
    render(<PrimaryActionBar primaryLabel="Continue" disabled onPrimary={onPrimary} />);
    const btn = screen.getByRole("button", { name: "Continue" });
    expect(btn).toBeDisabled();
    await userEvent.click(btn);
    expect(onPrimary).not.toHaveBeenCalled();
  });

  it("shows a busy state and blocks clicks while loading", async () => {
    const onPrimary = vi.fn();
    render(<PrimaryActionBar primaryLabel="Continue" loading onPrimary={onPrimary} />);
    const btn = screen.getByRole("button");
    expect(btn).toHaveAttribute("aria-busy", "true");
    expect(btn).toBeDisabled();
    expect(screen.getByText("Working…")).toBeInTheDocument();
    await userEvent.click(btn);
    expect(onPrimary).not.toHaveBeenCalled();
  });

  it("renders an optional secondary action and fires onSecondary", async () => {
    const onSecondary = vi.fn();
    render(
      <PrimaryActionBar
        primaryLabel="Meet a Forever Advisor"
        onPrimary={() => {}}
        secondaryLabel="Maybe later"
        onSecondary={onSecondary}
      />,
    );
    await userEvent.click(screen.getByRole("button", { name: "Maybe later" }));
    expect(onSecondary).toHaveBeenCalledTimes(1);
  });

  it("omits the secondary action when no label is given", () => {
    render(<PrimaryActionBar primaryLabel="Continue" onPrimary={() => {}} />);
    expect(screen.getAllByRole("button")).toHaveLength(1);
  });

  it("is keyboard operable (focus + Enter on primary)", async () => {
    const onPrimary = vi.fn();
    render(<PrimaryActionBar primaryLabel="Continue" onPrimary={onPrimary} />);
    const btn = screen.getByRole("button", { name: "Continue" });
    btn.focus();
    expect(btn).toHaveFocus();
    await userEvent.keyboard("{Enter}");
    expect(onPrimary).toHaveBeenCalledTimes(1);
  });
});
