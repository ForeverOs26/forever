import { useState } from "react";
import ProgressHeader from "./ProgressHeader";

/**
 * Example usage for ProgressHeader.
 *
 * ProgressHeader is presentation only — step state lives HERE in the parent.
 * This demo walks a 4-step flow forward/back to show the progress bar and
 * step count reacting to controlled props. No routing, no logic inside the
 * header itself.
 */
const STEPS = [
  { index: "01", title: "Why are you considering Phuket?", subtitle: "Choose up to three that ring true." },
  { index: "02", title: "What would success look like for you?", subtitle: "Not the property — the life it makes possible." },
  { index: "03", title: "What feels comfortable, and when?", subtitle: "A rough range is perfect." },
  { index: "04", title: "What's your biggest concern right now?", subtitle: "Be honest — this is what we help with." },
];

export default function ProgressHeaderExample() {
  const [step, setStep] = useState(1); // 1-based

  const s = STEPS[step - 1];

  return (
    <div className="mx-auto flex min-h-dvh w-full max-w-md flex-col bg-white">
      <ProgressHeader
        currentStep={step}
        totalSteps={STEPS.length}
        index={s.index}
        title={s.title}
        subtitle={s.subtitle}
        onBack={step > 1 ? () => setStep((n) => n - 1) : undefined}
      />

      <div className="mt-auto flex gap-3 p-[26px] pb-[34px]">
        <button
          type="button"
          disabled={step >= STEPS.length}
          onClick={() => setStep((n) => Math.min(STEPS.length, n + 1))}
          className="w-full rounded-[16px] bg-[#17150F] px-4 py-4 text-[16px] font-[600] text-white disabled:bg-[#EDE9E1] disabled:text-[#B7B2A6] [font-family:'Hanken_Grotesk',system-ui,sans-serif]"
        >
          {step >= STEPS.length ? "Done" : "Continue"}
        </button>
      </div>
    </div>
  );
}
