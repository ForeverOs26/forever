import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, it, expect, vi } from "vitest";
import ChoiceCard from "./ChoiceCard";

describe("ChoiceCard", () => {
  it("renders the title and optional description", () => {
    render(
      <ChoiceCard title="A slower way of living" description="Less rush, more room" />,
    );
    expect(screen.getByText("A slower way of living")).toBeInTheDocument();
    expect(screen.getByText("Less rush, more room")).toBeInTheDocument();
  });

  it("exposes checkbox semantics reflecting `selected`", () => {
    const { rerender } = render(<ChoiceCard title="Financial security" />);
    expect(screen.getByRole("checkbox")).toHaveAttribute("aria-checked", "false");
    rerender(<ChoiceCard title="Financial security" selected />);
    expect(screen.getByRole("checkbox")).toHaveAttribute("aria-checked", "true");
  });

  it("fires onClick when clicked", async () => {
    const onClick = vi.fn();
    render(<ChoiceCard title="Overpaying" onClick={onClick} />);
    await userEvent.click(screen.getByRole("checkbox"));
    expect(onClick).toHaveBeenCalledTimes(1);
  });

  it("is keyboard operable via Enter and Space", async () => {
    const onClick = vi.fn();
    render(<ChoiceCard title="Legal ownership" onClick={onClick} />);
    const el = screen.getByRole("checkbox");
    el.focus();
    expect(el).toHaveFocus();
    await userEvent.keyboard("{Enter}");
    await userEvent.keyboard(" ");
    expect(onClick).toHaveBeenCalledTimes(2);
  });

  it("does not fire onClick when disabled", async () => {
    const onClick = vi.fn();
    render(<ChoiceCard title="Hidden costs" disabled onClick={onClick} />);
    const el = screen.getByRole("checkbox");
    expect(el).toBeDisabled();
    await userEvent.click(el);
    expect(onClick).not.toHaveBeenCalled();
  });

  it("uses a custom ariaLabel when provided", () => {
    render(<ChoiceCard title="Exit strategy" ariaLabel="Concern: exit strategy" />);
    expect(
      screen.getByRole("checkbox", { name: "Concern: exit strategy" }),
    ).toBeInTheDocument();
  });

  it("marks the icon and selection dot as decorative (aria-hidden)", () => {
    const { container } = render(
      <ChoiceCard title="Freedom to travel more" icon={<svg data-testid="i" />} selected />,
    );
    expect(container.querySelectorAll('[aria-hidden="true"]').length).toBeGreaterThanOrEqual(2);
  });
});
