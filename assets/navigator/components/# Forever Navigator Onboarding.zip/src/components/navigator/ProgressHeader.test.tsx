import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, it, expect, vi } from "vitest";
import ProgressHeader from "./ProgressHeader";

describe("ProgressHeader", () => {
  it("renders title, subtitle and the zero-padded step count", () => {
    render(
      <ProgressHeader
        currentStep={1}
        totalSteps={4}
        index="01"
        title="Why are you considering Phuket?"
        subtitle="Choose up to three that ring true."
      />,
    );
    expect(
      screen.getByRole("heading", { name: "Why are you considering Phuket?" }),
    ).toBeInTheDocument();
    expect(screen.getByText("Choose up to three that ring true.")).toBeInTheDocument();
    expect(screen.getByText("01 / 04")).toBeInTheDocument();
  });

  it("exposes progressbar semantics with the computed percentage", () => {
    render(<ProgressHeader currentStep={2} totalSteps={4} title="Success" />);
    const bar = screen.getByRole("progressbar");
    expect(bar).toHaveAttribute("aria-valuenow", "50");
    expect(bar).toHaveAttribute("aria-label", "Step 2 of 4");
  });

  it("clamps currentStep within [0, totalSteps]", () => {
    render(<ProgressHeader currentStep={9} totalSteps={4} title="x" />);
    expect(screen.getByRole("progressbar")).toHaveAttribute("aria-valuenow", "100");
    expect(screen.getByText("04 / 04")).toBeInTheDocument();
  });

  it("calls onBack when the back button is activated", async () => {
    const onBack = vi.fn();
    render(<ProgressHeader currentStep={1} totalSteps={4} onBack={onBack} />);
    await userEvent.click(screen.getByRole("button", { name: "Back" }));
    expect(onBack).toHaveBeenCalledTimes(1);
  });

  it("hides the back button when no onBack is provided", () => {
    render(<ProgressHeader currentStep={1} totalSteps={4} title="x" />);
    expect(screen.queryByRole("button")).not.toBeInTheDocument();
  });

  it("is keyboard operable (back button focus + Enter)", async () => {
    const onBack = vi.fn();
    render(<ProgressHeader currentStep={1} totalSteps={4} onBack={onBack} />);
    const btn = screen.getByRole("button", { name: "Back" });
    btn.focus();
    expect(btn).toHaveFocus();
    await userEvent.keyboard("{Enter}");
    expect(onBack).toHaveBeenCalledTimes(1);
  });
});
