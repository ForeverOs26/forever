import { useState } from "react";
import ChoiceGroup from "./ChoiceGroup";
import type { ChoiceGroupItem } from "./ChoiceGroup";

/**
 * Example usage for ChoiceGroup.
 *
 * ChoiceGroup is presentation only — all selection rules live HERE in the
 * parent. This demo reproduces the frozen Navigator behaviour: multi-select,
 * max 3 with FIFO roll-off, an exclusive opt-out ("I'm still exploring") that
 * clears the others and is cleared by them, and non-chosen cards disabled
 * once the max is reached.
 */
const ITEMS: ChoiceGroupItem[] = [
  { key: "second_home", title: "A second home by the sea" },
  { key: "retirement", title: "Retirement in a warmer climate" },
  { key: "investment", title: "Investment & rental income" },
  { key: "slower_life", title: "A slower way of living" },
  { key: "family", title: "A place for my family" },
  { key: "wellbeing", title: "Better weather and wellbeing" },
  { key: "exploring", title: "I'm still exploring", dividerBefore: true, muted: true },
];

const MAX = 3;
const EXCLUSIVE = "exploring";

export default function ChoiceGroupExample() {
  const [selected, setSelected] = useState<string[]>([]);

  function onToggle(key: string) {
    setSelected((prev) => {
      if (key === EXCLUSIVE) return prev.includes(key) ? [] : [key];
      let next = prev.filter((k) => k !== EXCLUSIVE);
      if (next.includes(key)) next = next.filter((k) => k !== key);
      else if (next.length >= MAX) next = [...next.slice(1), key]; // FIFO
      else next = [...next, key];
      return next;
    });
  }

  const atMax = selected.length >= MAX && !selected.includes(EXCLUSIVE);
  const disabledKeys = atMax
    ? ITEMS.filter((i) => i.key !== EXCLUSIVE && !selected.includes(i.key)).map((i) => i.key)
    : [];

  return (
    <div className="mx-auto w-full max-w-md p-6">
      <ChoiceGroup
        ariaLabel="Why Phuket — select up to three"
        items={ITEMS}
        selectedKeys={selected}
        disabledKeys={disabledKeys}
        onToggle={onToggle}
      />
    </div>
  );
}
